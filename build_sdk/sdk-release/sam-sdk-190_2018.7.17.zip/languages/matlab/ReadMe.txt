The Matlab examples and wrapper code and classes requires Matlab cross compiling to be setup with an appropriate compiler. See http://www.mathworks.com/support/compilers/R2013a/index.html for supported compilers and see http://www.mathworks.com/help/matlab/ref/mex.html for help on configuring mex.

Note that on Mac OSX: if you use gcc, the supported version is 4.2 and requires a symbolic link 
ln -s /usr/bin/gcc /usr/bin/gcc-4.2

The UIExample.fig can be opened and run using GUIDE. For more information, see: http://www.mathworks.com/help/matlab/ref/guide.html